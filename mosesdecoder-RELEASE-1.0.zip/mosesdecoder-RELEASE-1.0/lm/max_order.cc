#include "lm/max_order.hh"
#include <iostream>

int main(int argc, char *argv[]) {
  std::cerr << "KenLM was compiled with a maximum supported n-gram order set to " << KENLM_MAX_ORDER << "." << std::endl;
}
